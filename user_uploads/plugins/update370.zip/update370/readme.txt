1. If you dont make any customization on any files then Just upload the zip from admin panel > upload and click "upload & install button"

or if you want to install the update manually

1. Replace ROOT/application directory with application directory [Merge and replace]
2. Replace ROOT/dbc_config directory with dbc_config directory [Merge and replace]
3. Replace ROOT/system directory with system directory [Merge and replace]
4. Replace ROOT/assets directory with assets directory [Merge and replace]

NB: Please create a sql backup before update. Also if any custom work is done on you script then please
replace files carefully so that your custom works do not loose. If possible take a file backup also.

The update pack contains css files , view files , language files. So please take backup before doing anything.