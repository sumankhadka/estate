<footer>
<p>
    <?php echo translate(get_settings('site_settings','footer_text','copyright@'));?>
</p>
</footer>
<a id="btn-scrollup" class="btn btn-circle btn-lg" href="index.html#"><i class="fa fa-chevron-up"></i></a>