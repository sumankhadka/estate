    <link rel="shortcut icon" href="<?php echo theme_url();?>/assets/images/favicon.ico">

    

    <link rel="stylesheet" media="screen" href="http://fonts.googleapis.com/css?family=Open+Sans:300,400,700">

    <link rel="stylesheet" href="<?php echo theme_url();?>/assets/css/bootstrap.min.css">

    <link rel="stylesheet" href="<?php echo theme_url();?>/assets/css/font-awesome.min.css">



    <!-- Custom styles for our template -->

    <link rel="stylesheet" href="<?php echo theme_url();?>/assets/css/bootstrap-theme.min.css" media="screen" >

    <link rel="stylesheet" href="<?php echo theme_url();?>/assets/css/main.min.css">

    <link rel="stylesheet" href="<?php echo theme_url();?>/assets/css/custom.min.css">
<!--    <link rel="stylesheet" href="--><?php //echo theme_url();?><!--/assets/css/owl.carousel.css">-->







    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->

    <!--[if lt IE 9]>

    <script src="<?php echo theme_url();?>/assets/js/html5shiv.js"></script>

    <script src="<?php echo theme_url();?>/assets/js/respond.min.js"></script>

    <![endif]-->

    <script src="<?php echo theme_url();?>/assets/js/jquery-2.1.1.min.js"></script>

    <script src="<?php echo theme_url();?>/assets/js/jquery-migrate-1.2.1.min.js"></script>

    <script src="https://maps.googleapis.com/maps/api/js?v=3.exp&libraries=places&key=<?php echo get_settings('realestate_settings', 'google_map_api', 'AIzaSyBvh1XqXYU-n-U6Z9tvzqZCBeyFn1EX_d0'); ?>"></script>


    <script src="<?php echo theme_url();?>/assets/js/markercluster.min.js"></script>
    <script src="<?php echo theme_url();?>/assets/js/owl.carousel.min.js"></script>

    <script src="<?php echo theme_url();?>/assets/js/modernizr.js"></script>


